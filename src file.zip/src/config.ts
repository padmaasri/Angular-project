export const config = {
    // url: "https://suliyambackend.technogenesis.in/api/V1/AP"
    url: "http://localhost:3000",
    portUrl: "http://localhost:4000",
    apiUrl: "https://dummyjson.com"
}