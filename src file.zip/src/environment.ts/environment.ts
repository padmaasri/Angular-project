import { config } from "src/config";

export const environment = {
    production: false,
    url: config.url,
    portUrl: config.portUrl,
    apiURL: config.apiUrl


};