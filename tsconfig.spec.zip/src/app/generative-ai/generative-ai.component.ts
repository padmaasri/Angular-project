import { Component } from '@angular/core';
import axios from 'axios';
import { ServiceService } from '../service.service';


@Component({
  selector: 'app-generative-ai',
  templateUrl: './generative-ai.component.html',
  styleUrls: ['./generative-ai.component.css']
})
export class GenerativeAiComponent {
  messages: any[] = [];
  file: File
  userInput: string = '';
  generatedImages: string[] = [];
  prompt = '';
  generatedImage: string[] = [];
  audioUrl: any;
  generateaudios: any;
  constructor(private service: ServiceService) { }

  async sendMessage() {
    this.messages.push({ role: 'user', content: this.userInput });
    try {
      const response = await axios.post('https://api.openai.com/v1/chat/completions', {
        model: 'gpt-3.5-turbo',
        messages: this.messages,
        temperature: 0.8

      },

        {
          headers: {
            Authorization: 'Bearer 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'
          }
        });

      const rply = response.data.choices[0].message.content;
      this.messages.push({ role: 'system', content: rply });
    } catch (error) {
      console.error('Error sending message:', error);
    }
  }
  // In generative-ai.component.ts
  async sendMessageAndGenerateImage() {
    await this.sendMessage();
    await this.generateImage();
    //    await this.onFileSelect(this.type)

  }

  ngOninit() {
    // this.onFilesDropped()
  }
  generateImage() {
    this.service.generateImage(this.userInput).subscribe((response: any) => {
      this.generatedImages = response.data.map((imageData: any) => imageData.url);
      console.log(this.generatedImages, "images");
    });
  }

  generateAudio(userInput) {
    this.service.generateAudio(userInput).subscribe(
      (response) => {
        if (response) {
          console.log(response, "resssssssssssssss")
          const audioElement = new Audio('data:audio/mp3;base64,' + response);
          audioElement.play();
        } else {
          console.error('Audio generation response does not contain audio data');
        }
      },
      // (error) => {
      //   console.error('Error generating audio:', error);
      // }
    );
  }




}

