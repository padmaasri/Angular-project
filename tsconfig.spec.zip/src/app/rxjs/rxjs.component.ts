import { Component, computed, signal } from '@angular/core';

import { audit, auditTime, count, debounce, debounceTime, fromEvent, interval, of, pipe, take, throwError } from 'rxjs';

@Component({
  selector: 'app-rxjs',
  templateUrl: './rxjs.component.html',
  styleUrls: ['./rxjs.component.css']
})
export class RxjsComponent {


  count = signal(0)
  btn: any
  form: any
  math: any
  newval: string[] = []
  val2: any = []
  number
  number1: any
  spreaarry: any = []
  min = 3;
  sec = 59
  game
  gametype: boolean = false
  start() {
    this.game = setInterval(() => {
      this.sec--
      if (this.min == 0 && this.sec == 0) {
        alert("time mudunju")
        this.gametype = true
        this.game = clearInterval(this.game)
        window.location.reload

      }
      else if (this.sec == 0) {
        this.min--
        this.sec = 59

      }
    }, 500)

  }
  stop() {

    this.game = clearInterval(this.game)
  }
  add() {

    this.newval.push(this.value)
    console.log(this.newval)
  }
  // firstname = signal("padma")
  // lastname = signal("sri")
  // fullname = computed(() => this.firstname() + this.lastname())
  // value: any
  // click() {
  //   alert(
  //     this.fullname())
  // }

  multiple: number; // Set the number for multiplication
  multipli: number[] = Array.from({ length: 10 });
  results: number[] = [];


  // table() {

  //   console.log(this.number)
  // 

  showTable: boolean = false;
  value

  table() {
    this.multipli = Array.from({ length: 10 }, (_, i) => i + 1);
    console.log(this.multipli)
    this.showTable = true;
  }
  ngOnInit() {
    // this.audit()
    this.add()
    this.table()

    // for (let i = 1; i <= 10; i++) {
    //   this.result.push(this.multiple * i)

    // }
    // console.log(this.result)

    console.log(this.count() * 2)

    /* ...................interval............... */

    // let inter = interval(500)
    // let val = inter.pipe(take(10))
    // val.subscribe(x => {
    //   this.val2 = x;
    //   console.log(x)
    // })

    /* ...................of & spread arry............... */


    // this.spreaarry = ["bala", "arru"]
    // this.val2 = [...this.spreaarry, "padma", "sri", "malli", "meenu"]
    // let ofval = of(this.val2);
    // ofval.subscribe(res => {
    //   this.val2 = res;
    //   console.log(this.val2)
    // })



    /* ...................throw error............... */
    // let error: any = throwError(new Error("error in window"))
    // error.subscribe(e => {
    //   error = e
    //   console.log(error)
    // })

    // this.math = (Math.random() + 1) % 2 === 2 ? "even" : "odd";
    // console.log(this.math)

    // let inter = interval(1000)

    // this.number = inter.pipe(count());
    // this.number1.subscribe(res => {
    //   this.number1 = res
    //   console.log(res)
    // })


  }

  // audit() {
  //   this.auditval = of(1, 2, 3, 4, 5)
  //   this.test = this.auditval.pipe(debounceTime(1000))
  //   this.test.subscribe(x => {
  //     this.test = x
  //     console.log(x, "test")
  //   })
  // }
  // auditval
  // test: any


}
