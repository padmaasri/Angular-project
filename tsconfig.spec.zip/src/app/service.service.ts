import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { io } from 'socket.io-client';
import { ApiserviceService } from './apiservice.service';
@Injectable({
  providedIn: 'root'
})
export class ServiceService {
  private apiUrl = 'https://dummyjson.com';
  // constructor(private http: HttpClient) { }

  // getimage(data): Observable<any> {
  //   return this.http.post(`https://api.openai.com/v1/images/generations`, data)
  // }

  getList(pagination: any): Observable<any> {
    let params = new HttpParams();
    for (let data in pagination) {
      if (pagination[data]) {
        params = params.append(data, pagination[data]);
        console.log(params, "params")
      }
    }
    return this.serviceService.get('/products', params)
  }
  postlogin(data): Observable<any> {
    return this.http.post(`http://localhost:3000/users`, data);
  }
  uploadImage(data): Observable<any> {
    return this.http.post(`http://localhost:3000/images`, data)
  }

  public message$: BehaviorSubject<string> = new BehaviorSubject('');
  constructor(private http: HttpClient,
    private serviceService: ApiserviceService) {

  }
  // socket = io('http://localhost:3000');

  // public sendMessage(message) {
  //   this.socket.emit('message', message);
  // }

  // public getNewMessage = () => {
  //   this.socket.on('message', (message) => {
  //     this.message$.next(message);
  //   });

  //   return this.message$.asObservable();
  // };
  // shareVideo(videoData: string) {
  //   this.socket.emit('shareVideo', videoData);
  // }

  private apiKey = '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';


  generateImage(data) {
    const headers = {
      'Authorization': `Bearer ${this.apiKey}`
    };
    data = {
      prompt: data,
      n: 2,
      size: "512x512"
    };

    return this.http.post(`https://api.openai.com/v1/images/generations`, data, { headers });
  }

  // generateaudio(audioFile: File, model: string) {
  //   console.log("dhfghgfhg")
  //   const headers = {
  //     'Authorization': `Bearer ${this.apiKey}`
  //   };

  //   const formData = new FormData();
  //   formData.append('file', audioFile, audioFile.name);
  //   formData.append('model', model);
  //   return this.http.post(`https://api.openai.com/v1/audio/transcriptions`, formData, { headers });

  generateAudio(prompt: string) {
    const headers = new HttpHeaders({
      'Authorization': `Bearer ${this.apiKey}`,
      'Content-Type': 'application/json',
    });

    const data = {

      model: 'whisper-1', // The desired voice model (e.g., 'whisper-1')
      file: 'mp3', // The desired audio format (e.g., 'mp3', 'wav', etc.)
      // Additional parameters as needed
    };

    return this.http.post(`https://api.openai.com/v1/audio/generation`, data, { headers });
  }
}
